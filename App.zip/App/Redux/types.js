export const LOGOUT = 'LOGOUT';
export const LOGIN = 'LOGIN';
