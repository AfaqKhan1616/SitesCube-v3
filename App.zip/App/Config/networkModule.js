export const devBaseURL = `https://www.sitescube.com/api`;
