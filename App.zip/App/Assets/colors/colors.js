const black = '#000000';
const blackThree = '#121212';
const white = '#F5F5F5';
const blackTwo = '#333333';
const greyish = '#b3b3b3';
const mainBlue = '#2977DD';
const lightGrey = '#EDEEEF';
const warmGrey = '#9b9b9b';
const lightPink = '#f5665b';
const lightBlue = '#c5dafa';

export {
  black,
  white,
  blackTwo,
  blackThree,
  lightGrey,
  greyish,
  warmGrey,
  mainBlue,
  lightPink,
  lightBlue,
};
